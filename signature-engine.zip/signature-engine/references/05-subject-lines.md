# The Open — from-name, subject line, preheader, first line

## Four things decide whether it gets read at all

| # | What | Why |
|---|---|---|
| 1 | **The from-name** | **A person, never a company.** People open people. This matters more than the subject line and almost nobody optimises it. "Scott at Hodgson Plumbing" beats "Hodgson Plumbing Ltd" |
| 2 | **The subject line** | Under 55 characters. Specific, not mysterious |
| 3 | **The preheader** | The grey line the inbox shows next to the subject. A free second sentence. Most businesses waste it by repeating the subject or leaving it blank. **Add, never echo** |
| 4 | **The first line** | The first thing after opening, and on many phones part of the preview too. Never spend it on "hope you're well" |

Get all four right and a small list will out-open a big brand's list every time.

## The real data

This is fourteen issues of a real newsletter sent to the same audience in one year. Same writer, same brand, same day of the week. **The only variable that changed was the subject line.**

| Open rate | Subject line | Why it worked |
|---|---|---|
| **42.8%** | 3 New Year Lessons I Wish Someone Told Me When I Was 30 | A number, a confession, a specific age |
| **39.9%** | A Stunning Prediction for the Next 10 Years | A defined timeframe you can picture |
| **39.0%** | The $10,000 Decision That Taught Me How the World Actually Changes | A real price, on the table, in the subject |
| **38.3%** | I'm Turning 50. So I Decided to Live 100 Lives. | First person, genuinely unexpected |
| **37.9%** | I read a study that made me stop aging myself | Plain, human, lower case, no performance |
| **36.2%** | The Four-Day Work Week is Officially Here | A flat statement of fact |
| **31.2%** | Nobody will tell you this publicly.. | **Pure curiosity gap. No specifics. Last of fourteen.** |

Median across the fourteen: **37.8%**. Unsubscribe rate range: **0.05%–0.13%**. The gap between best and worst: **11.6 points.**

## Specific beats mysterious. Every time.

Look at that bottom row. That is the subject line every marketing course on earth teaches you to write — the curiosity gap. On a real list, at scale, it came **last out of fourteen**.

**Here's why.** The reader isn't deciding whether to be curious. They're deciding, in about a fifth of a second, whether **you** are worth ninety seconds of their morning. Specificity is the only evidence they have. A number, a price, a date, a confession — that's proof there's something real inside. Mystery is a promise with no collateral, and their inbox is already full of promises.

**And the second-order effect matters more.** Clickbait wins the open and loses the trust, so it drives unsubscribes and spam complaints — the two numbers that decide whether they reach the inbox *at all* next month. **An honest subject line is a deliverability strategy.**

So: tell them exactly what's inside. The ones who want it will open every time — and those are the only people who were ever going to buy anything.

## Five shapes that work

| Shape | Example |
|---|---|
| **Number + lesson** | "3 things I got wrong about pricing jobs" |
| **The confession** | "I read a study that changed how I quote" |
| **The real price** | "The £4,200 job I was sure I'd lost" |
| **The plain question** | "Should you ever be the cheapest quote?" |
| **Flat statement of fact** | "The new rules come in on 1 October" |

## The rules

- **Under 55 characters.**
- **No colons.**
- **No emojis.**
- **Sentence case, not Title Case.**
- **No word they wouldn't say in a pub.**
- **Honest** — it must describe what's actually inside.

## The preheader

Write it as the **second sentence**, not a rewrite of the first.

> Subject: *"The £4,200 job I was sure I'd lost."*
> Preheader: *"And the one line that won it back."*

Together they're an argument. Separately they're both wasted.
