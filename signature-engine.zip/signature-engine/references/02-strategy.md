# Strategy — the decisions, the models, and a full year of topics

## The order matters

Settle the decisions → get their stories → research their market → **then** build the topics. Never invent topics before you know what material they actually have. Building the year around stories they already own is the difference between a plan they can execute and a plan they abandon in week three.

## Part one — the six decisions

Ask one at a time, four lettered options each. Don't move on without a real answer — everything downstream depends on these, so don't assume any of them.

1. **Are these four pillars right?** Show them back and ask if they want to change one.
2. **Founder or company newsletter?** See below. If unsure, ask which they'd still write on the week their business is on fire. Don't let them pick both.
3. **Long form or short form?** Long is 800–1,200 words, about a four-minute read. Short is 180–350, about ninety seconds. Tell them which you'd pick and why, then let them decide.
4. **How often, and which day?** Before they answer, tell them plainly how many issues a year each option means — weekly is 52, fortnightly 26, monthly 12 — so they choose with their eyes open.
5. **How much time in their WORST week, not their best?** If the answer doesn't match the cadence they picked, say so directly and give them the cadence you actually believe they'll keep.
6. **What are they selling over the next twelve months?** Offers, prices, and any dates or launch windows they already know.

Then ask if there's anything they refuse to write about.

## Founder or company newsletter

|  | Founder's newsletter | Company newsletter |
|---|---|---|
| **Whose name** | Theirs. A person. | The brand — but still signed by a human |
| **The subject** | How they think. Their position, decisions, mistakes. | Their reader's world. Written for one job title's problems. |
| **What it's for** | Trust, authority, inbound. People buy *them*. | Retention, education, repeat work. People buy *the service*. |
| **Voice** | First person, opinionated. Allowed to be wrong in public. | Useful before it's personal. |
| **Survives** | A rebrand, a pivot, a sale, their next business. It's theirs. | As long as the company does. It's a business asset. |
| **Right for** | Anyone selling judgement — coaching, consulting, advice | Services where the buyer is a role: facilities manager, site manager, practice owner |
| **Watch out for** | They can never fully hand it over. That's the cost of it being theirs. | Drifts into a company update nobody reads. Keep it about the reader. |

Both eventually. One now. If they're the face of the business, the founder's newsletter is worth more and they should start there.

## The five newsletter models

Every good newsletter in the world is one of these. Help them recognise theirs rather than prescribing.

| Model | What it is | Real example | Fits |
|---|---|---|---|
| **The Curator** | You read the firehose so they don't. Five things, filtered, plain English, same slots every time. | Morning Brew | Anyone in a fast-moving or regulated trade |
| **The Teacher** | One idea, explained properly. No news, no urgency, identical shape every issue. | James Clear's 3-2-1 — every Thursday: 3 ideas, 2 quotes, 1 question | Coaches, consultants, advisors |
| **The Practitioner's Log** | One thing you actually did this week, and what happened. | Justin Welsh, The Saturday Solopreneur | Most small business owners |
| **The Deep Dive** | One properly researched piece a week. Interviews, data, frameworks. Long. | Lenny's Newsletter — 1,000+ words, 10–20 hours an issue, people pay for it | Only if they love writing |
| **The Trade Brief** | Narrow niche, high value, deliberately unglamorous. Written for one job title. | Stratechery — one analyst, one professional audience, thousands of paying subscribers | Services where the buyer is a role |

**The thing to say out loud:** four of the five don't require them to be a writer. They're the user reporting on things that already happen. Only the Deep Dive needs someone who loves writing — so don't let them pick it because it looks impressive. Push back once: *"do you actually enjoy writing? Be honest."*

**How to find theirs, out loud rather than prescribed.** Four questions:
1. Who's the one person you want reading it? Not a market — one actual client you've had.
2. What do they say in the first ten minutes of a call, before you've fixed anything?
3. What do you know that most of them find genuinely surprising?
4. Could you write one of these on your worst week of the month?

Answer those four and the model picks itself.

## The strategy output

Short, no preamble:

- **WHO IT'S FOR** — one real person in two sentences, including what they're worried about before they ever speak to the user. Not a demographic.
- **THE PROMISE** — one sentence in the form *"every issue, you'll get…"*, written to the reader. Concrete enough that someone could tell if it had been failed. This is Oshinsky's test: a promise the reader understands and the user can keep every single week.
- **THE NAME** — your single best pick plus three alternatives. Clear beats clever. If a name would need explaining to a client, don't offer it. One line on why you chose yours.
- **THE SHAPE** — the sections in order, with a word count against each and a total. This never changes from issue to issue; that repetition is what lets someone read on autopilot.
- **THE CADENCE** — the day, the frequency, and how many issues that is for the year.

## Part two — research before topics

Search the web properly and use current sources. Be extensive — this is what stops the plan being generic. For each pillar find:

- The questions real people in the customer's job are asking **this year**, in their own words — forums, trade press, community threads, search behaviour
- What has changed recently in their industry — rules, regulation, prices, technology, expectations — and when
- The two or three things everyone in the industry repeats that are worth arguing with
- Anything coming in the next twelve months their customers will need to be ready for

Deliver a **research summary**: no more than five bullets per pillar, each a real question or a real change, with a note on where it came from. **If you can't verify something, leave it out rather than guessing.** Keep it tight — it exists to make the plan good, not to be read for its own sake.

## Part three — twelve months of topics

Size it to the cadence they chose:

- **Weekly** → 52 topics, 13 per pillar
- **Fortnightly** → 26 topics, six or seven per pillar
- **Monthly** → 12 topics, three per pillar

Use the right number. Don't give fewer because it's long, and don't give more.

**Build it in this order — this is the important part:**

1. **Turn every story in their story bank into a topic**, and put those first in the year. Each one names which story it uses.
2. **Fill the rest** from your research and from things they'd already know from doing their job.
3. For any topic without a story attached, write **"needs a story — watch for this"**. That quietly turns the plan into their capture list, which is worth as much as the plan itself.

Rules:
- Every topic is a real, specific working title. Not a theme, not a category.
- Label the pillar against each one.
- **Sequence so no two neighbouring issues come from the same pillar.**
- Give it as a month-by-month table: send date, working title, pillar, source (story number / research finding / "needs a story").
- Put anything seasonal in the right month. If their business has a busy season, put the easiest topics there.
- Star the single easiest one to write and make it issue one.
- No topic may need research they wouldn't already have done by doing their job.

## Part four — the first four issues

Finish the strategy by picking the issues they'll actually write first, because a year plan with no starting point doesn't get started.

Pick **four — exactly one from each pillar**, choosing the strongest story in each. Every one must already have a story attached from the bank. **Never pick a "needs a story" topic** for the first four; those are for later, once the capture habit is running.

Deliver it as a four-row table: **send date · topic · pillar · story number · the moment in one line · the detail · the number · the point.**

That table is what the writing work draws from — one issue per row. Say which of the four to publish first, and why.

## The specificity ladder

The single biggest upgrade available to most topics. Go narrower than feels sensible — **every rung down doubles the audience that cares.** That feels wrong and it's true: broad topics get skimmed by everyone and read by nobody; narrow topics get forwarded.

| | |
|---|---|
| Useless | Marketing tips for tradespeople |
| Still too broad | How to price a job properly |
| Getting there | Why the cheapest quote costs the client more |
| **This is an issue** | The one sentence I say when a client tells me someone else quoted 40% less — and why it wins the job about half the time |

## The topic test

Four questions, all must be yes:

1. **Can I write this without researching anything?** If no, it's a project, not an issue. Projects don't get sent.
2. **Is it about one thing?** If you need "and" to describe it, that's two issues. Congratulations — next week is sorted too.
3. **Would the reader recognise themselves in the first line?** If the opening is about the user and not the reader, they've lost everyone who doesn't already know them.
4. **Would one person forward this to one specific colleague?** Not "would it go viral". Would *Dave send it to Steve*. That's the real bar, and it's much lower than people think.

A topic that passes all four takes twenty minutes to write. One that fails one takes three hours and still feels wrong.
