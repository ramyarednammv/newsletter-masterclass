# Positioning and the four pillars

## Why this comes first

Founders don't have writer's block. They have **position block**.

Nobody struggles to talk for an hour about their own business. Put the same person in front of a blank email and nothing comes out. That's not a writing problem — it's that they've never been forced to decide, in one sentence, what they actually believe. Talking lets you hedge. Writing doesn't.

Once someone knows what they think, they stop inventing content. They just report what they already believe, one piece at a time. That's the difference between a newsletter taking twenty minutes and taking two hours.

**The gap to name explicitly:** a Personal Brand OS or voice profile captures how they *sound* — story, tone, humour, vocabulary. It never asks what they *think*. Voice without a position is a very well-dressed person with nothing to say.

## The four lenses

Use these as how you think, and as a silent audit before showing output. Don't narrate which one is asking.

| Lens | What they insist on |
|---|---|
| **April Dunford** | Start with what customers would do if you didn't exist. Never start with features. Position on what the alternatives get wrong. |
| **Al Ries & Jack Trout** | One word or idea you can own in the customer's head. And who or what you're positioned against. |
| **Andy Raskin** | Name the change happening in their world, and who wins and loses because of it. Urgency comes from a shift, not from you. |
| **Chris Do** | Could a twelve-year-old repeat it and get it right? If not, it's not clear yet. |

## The eight questions

Ask one at a time, four lettered options each, in this order. The order matters — Dunford's competitive-alternatives question first anchors everything that follows, because a position built without knowing what you're compared against is just a description of yourself.

1. If I didn't exist, what would my customers actually do instead? Include doing nothing.
2. What do those alternatives get wrong that I get right?
3. What do I believe about my industry that most people working in it would argue with?
4. What annoys me most about the way my industry treats its customers?
5. What has changed in my industry in the last three years that my customers haven't caught up with yet?
6. What took me years to learn that I could teach someone in ten minutes?
7. What do clients thank me for that I think is obvious?
8. In three years, what do I want to be the person people call about?

Questions 4 and 7 are the highest-yield in practice. Anger is the cheapest source of honest writing anyone owns. And what's obvious to them is worth money to their reader — that's the richest question on the list, and they'll almost always undervalue their answer.

## The output

Keep every part short. Deliver exactly this and nothing else:

**MY POSITION** — one sentence. What they believe that others in their industry don't. Specific enough that a competitor could read it and disagree out loud.

**THE WORD I OWN** — the one word or short phrase they want to be the first name people think of for. Just the word, and one line on why it's ownable.

**WHAT I AM AGAINST** — the belief or habit in their industry they're arguing with. One sentence. Not a competitor's name.

**MY FOUR PILLARS** — see below.

Then stop, and ask one question: which pillar feels wrong? Offer to swap it.

## The audit before you show anything

Run all four and fix what fails:

- **Dunford:** is the position built on what the alternatives get wrong, or is it just a description of them? If it's a description, rebuild it.
- **Ries & Trout:** is the word actually available, or does a bigger competitor already own it? If it's taken, find one that isn't.
- **Raskin:** does the position imply a change in the world that makes it urgent now? If not, connect it to one.
- **Chris Do:** could a twelve-year-old repeat it? If not, cut the jargon and say it again.

**The test to give the user:** read your position out loud to someone in your industry. If they say *"well, hang on…"* you've got it. If they just nod, it's too safe.

## The four pillars

The four themes they'll be known for. Everything they publish sits inside one. Nothing sits outside.

**Four is the number.** Not three, not six. More than five and they'll forget which one they're writing for.

**A pillar is a theme, not a topic.** "How we price jobs" is a pillar. "Tuesday's issue" isn't.

For each pillar give: the name, one line on why their customer cares, and whether it's mainly **AUTHORITY** (they know things) or **AFFINITY** (people trust and like them). Aim for three authority and one affinity. Authority without affinity reads as a textbook; affinity without authority reads as a diary.

### Where pillars come from

Three ingredients, and a pillar needs all three:

1. **What they know deeply** — ten years of scar tissue. Things they could argue about on stage with no notes.
2. **What their buyer actually asks** — not what they wish they asked. The real questions, in real words, from real calls.
3. **What quietly leads somewhere** — not every issue pitches, but every pillar should relate to why they're in business.

Miss the first and it sounds generic. Miss the second and nobody cares. Miss the third and they build an audience that will never buy anything.

### The tests

- **Twenty issues, no research.** Each pillar must be something they could write about for a year without looking anything up. If not, it's a topic, not a pillar.
- **At least three must be able to lead to paid work.** One hobby pillar is allowed. Four isn't.
- **The competitor test:** would another business in their space use these exact four? If yes, narrow them until they wouldn't.

### The rotation rule

**Never two issues from the same pillar back to back.** That one rule solves drifting *and* repeating yourself, forever. Apply it when sequencing the year.

### Refreshing, not replacing

When a pillar feels stale it needs new angles, not abandonment. Review every six months — never mid-quarter, and never quietly.

## Two worked examples

**A plumbing contractor, £50k/month:**
1. Pricing and quoting honestly — *authority*
2. What goes wrong on site, and why — *authority*
3. Compliance and regulation changes — *authority*
4. Running a crew: hiring, standards, vans — *affinity*

**A high-ticket coach:**
1. Where founder energy actually goes — *authority*
2. The decisions that burn people out — *authority*
3. What clients say in the first ten minutes — *authority*
4. What I get wrong in my own week — *affinity*

Notice both sets would be unusable by a competitor in a slightly different niche. That's the bar.
