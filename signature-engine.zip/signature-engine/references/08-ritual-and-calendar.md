# The ritual, the honest maths, and the calendar

## What's actually being built

Not content. **A habit, in someone else's week.**

A newsletter works when the reader stops *deciding* whether to open it. That's the aim: to become the thing that arrives on a Thursday that they no longer evaluate.

Habits in other people work exactly like habits in yourself: **a consistent cue, a predictable reward, and repetition through the weeks you don't feel like it.** Which means the boring decisions — what day, what shape, what promise — matter more than anything they'll ever write.

**Most newsletters don't die because the writing was bad. They die because they were unpredictable.**

## The six mechanics of expectation

1. **Same day, same time.** The day becomes part of the name — Thursday's letter, the Friday note. That's why a title like "Free Your Friday" works: it tells you when it lands before it tells you anything else. Pick the day and never move it.
2. **Same shape.** Same sections, same order, every issue. Familiarity is what lets someone read on autopilot with a coffee in one hand. Resist redesigning. **Boring consistency *is* the brand.**
3. **Same promise, delivered.** They subscribed to exactly one thing. Deliver that thing. Slow drift into whatever the user fancies writing is the quiet killer — nobody complains, they just stop opening.
4. **Same name in the from-field.** A person, not a company. Never change it once readers have learned it.
5. **Name the next one.** End every issue with one line on what's coming next time. It turns a series of emails into a serial — and it creates a deadline they've already announced publicly. (Lenny Rachitsky's main consistency tip is exactly this: commit out loud so other people's awareness holds you to it.)
6. **Show up on your worst week.** Turning up with two hundred words on the week they had nothing is what actually builds the habit — in the reader and in them. **A short issue beats a skipped one. Every skip resets the clock.**

## The five ways it dies

1. **Going quiet, then coming back apologising.** Nobody ever unsubscribed because a newsletter arrived less often. They unsubscribe when it stops and returns with an apology — because the apology tells them it'll stop again.
2. **Changing the day.** The cue has been deleted. Expect the open rate to drop and take two months to recover.
3. **Changing the promise.** Most of them are only there for the original thing.
4. **Going long when they expect short.** The reader budgeted ninety seconds. Overrun it and they start saving it for later. Nobody reads "later".
5. **Selling three issues in a row.** One ask per issue is a habit. Three in a row is a campaign.

## The honest maths on effort

One issue, start to sent:

| Step | Time |
|---|---|
| Drafting from a voice note or their captured material | 20 min |
| Making it sound like them — filling the `[HUMAN]` bits, cutting a third, reading it aloud | 10 min |
| Into the email tool and sent — images, formatting, test send | 10 min |
| **Per issue** | **40 min** |

Plus **five minutes a day of capture**, which is what makes the 40 minutes possible.

**Without a strategy it's two hours**, because they start every issue by deciding what it is all over again. That difference is what the strategy work buys them.

## Choosing cadence honestly

**Pick the cadence you can hit on your worst week, not your best.**

| Cadence | When it's right |
|---|---|
| **Weekly** | The strongest — builds the habit fastest, in them and in the reader. Right if their business *is* their audience: coaches, consultants, advisors |
| **Fortnightly** | Works properly, nobody feels short-changed. Right if they run crews, vans, sites, a clinic. **Start here rather than promising weekly and stopping in October** |
| **Monthly** | Works, and nobody minds at all. Right if the buying cycle is long and the weeks are genuinely unpredictable |

Say the reassurance out loud: **nobody has ever unsubscribed because a newsletter arrived *less* often.**

## Plug into a ritual they already have

If the user already runs a weekly content session, **don't build a second ritual — add one output to the one they've got.**

**Sunday, 30 minutes → pick the week's strongest real moment → four social pieces + one newsletter issue.**

Same idea, both places, different job. Social gets the short punchy version to strangers; the newsletter gets the full version with the number and the nuance, to people who asked for it. **They're not producing twice the content — they're producing one thought at two depths.**

**One real difference worth flagging.** Good social advice says *don't end a post with a lesson or a moral* — on a feed, a moral reads as preaching to a stranger. A newsletter is the opposite: they opted in, so the "here's what to do about it" section is precisely what they came for. **Same story, different ending.**

## The calendar

**Four columns. That's the whole system.** If the calendar needs a tool, they won't keep it.

| Date | Topic | Pillar & source | The ask |
|---|---|---|---|
| Thu 14 Aug | The £4,200 quote I thought I'd lost | Pricing · voice note | Reply — what would you have said? |
| Thu 21 Aug | 3 things I get asked on every site visit | On site · capture note | Reply |
| Thu 28 Aug | The new rules from 1 October | Compliance · trade email + my read | Book a compliance check ← *the 10%* |
| Thu 4 Sep | What building my own software taught me | Software diary · photo | Poll |

Rules that make it survive:

- **Ten topics in the bank at all times.** Refill when it drops below five. Never write from empty.
- **Always keep one finished issue in reserve.** This single habit separates the people still sending in a year from the people who aren't.
- **Batch the thinking, not the writing.** One hour a month choosing topics and their sources; forty minutes a week actually writing. Batch-writing four issues in a day sounds efficient and produces four issues that all sound the same.
- **Check the pillar column for rotation** — no two neighbours the same.
- **Slot the asks in advance**, so 90/10 is a calendar rule rather than a willpower problem.
- **Mark their busy season now** and pre-write those issues while it's quiet. They already know which weeks they are.
- **Review monthly, not daily.** Checking in too often creates anxiety; monthly creates improvement.

## Patience — say this honestly

It took **two years** to build the engine behind a three-million-subscriber list. Not two years learning to write — two years of showing up every week and testing hard.

- **Their first ten issues will be their worst ten.** Send them anyway. That's the price of the eleventh.
- **Test one thing at a time.** A subject line, a send day, an ask. One variable, then look at the number.
- **Nothing compounds in month one.** It compounds in month nine, and then it doesn't stop.
- **All they have to do is show up every week.** That is genuinely the whole strategy; everything else just makes showing up easier.

**The people who win at this are not the best writers. They're the ones still sending in eighteen months.**
