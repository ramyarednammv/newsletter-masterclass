# Stories — the story bank and the seven beats

## Why story is the whole thing

Nobody remembers the point. They remember the story, and the point comes with it.

The mistake nearly everyone makes: lead with the lesson, then bolt an example on afterwards. It reads as a lecture, and readers feel a lecture coming from the first line.

Do it the other way round. Put the reader inside a specific moment first, and let them **arrive** at the lesson half a second before you name it. That half-second is why they finish, and why they reply.

## You don't invent content. You document your business.

People run dry because nothing is being written down — not because their week was boring. The material is already happening:

- **Wins and fails** — the job they landed, the one they lost and what it cost
- **Conversations** — what a client asked, what a friend or their partner said that stuck. **The richest source there is, and almost nobody uses it.**
- **Experiments** — the thing they tried this month
- **Pictures** — the site, the whiteboard, the mess. Photograph it.

Documenting daily is the whole job. Writing is just tidying it up afterwards.

## Where issues come from

Three sources. The good issues come from two of them at once — a client's question *plus* a number; their own job *plus* a study.

| Source | Why it works | Watch out |
|---|---|---|
| **Their own work** — jobs, decisions, mistakes, numbers they track | Highest trust, zero research | — |
| **Their audience's mouth** — the questions clients ask, what they misunderstand every single time, objections, what they say in the first ten minutes | Highest relevance. The richest source. | Almost nobody mines it |
| **The world** — one study, one number, filtered through their own experience | Most shareable | Useless on its own. Never report it straight |

## If they already keep a daily debrief

Many founder programmes teach an end-of-day debrief. If the user has one, it's already collecting newsletter material and they don't know it. Map it for them:

| Debrief question | What it becomes |
|---|---|
| What a client said, word for word | **The scene.** The most valuable line in any issue |
| What surprised you today | **The turn** |
| What you changed your mind about | The most trusted thing a founder can publish |
| What frustrated you, and what you did | The contrarian issue |
| One real number from today | **The proof.** This is what stops writing sounding like AI |
| What you'd tell another founder facing this | **The transfer** — the value section, already written |
| The bit you probably shouldn't share | The issue people forward. Handle with judgement |

If they're doing this, they already have months of material sitting in their notes.

## The capture habit

Four rules. Sixty seconds a day beats two hours on a Sunday.

1. **One place.** A phone note called "Newsletter", or wherever their diary already lands. Not five places, not a system.
2. **Capture the specific, never the theme.** Not "pricing". Write: *"Mrs Patel asked why my quote was 40% higher — I said because theirs doesn't include the making-good."* The specific version is already half an issue. A theme is a blank page.
3. **Capture at the moment of irritation.** The second they think *"why does everybody get this wrong"* — that's an issue. That feeling is the signal and it fades within the hour.
4. **Never delete a bad idea.** Two bad ideas next to each other become one good idea about six weeks later.

One thing the diary won't collect: **the sentence they've said on forty calls and stopped noticing.** That's usually their best issue, invisible to them precisely because it's automatic. Ask what they always say — or tell them to ask their team.

## Talk, don't write

The unlock for anyone who says "I'm not a writer."

Every founder can talk brilliantly for five minutes and then write a terrible paragraph about the same thing. So don't write the first draft. **Say it.**

**Go for a walk → talk for three minutes → paste it in unedited → shape it.**

- Use whatever's to hand: the Claude app, a meeting-notes tool, voice memos, phone dictation.
- **Don't tidy the transcript.** The mess is the raw material. The false starts and the bit where they correct themselves is where the good line hides.
- **Tell the story, not the lesson.** Talk about what happened; find the point afterwards.
- **Three minutes of talking is roughly one issue.** Twelve minutes on one walk is a month of newsletters.
- Use the alone time they already have — the walk, the drive, ten minutes in the van before a job. That's the writing desk now.

## Photos

Their camera roll is the most under-used marketing asset in the business. A real photograph is the one element of an email nobody can convincingly fake, which makes it proof.

**Photograph:** the job before/during/the ugly middle · the thing that broke and the part that caused it · a whiteboard, a scribbled quote, a screen · the van, the crew, the site at 7am · their desk, honestly · the event — the corridor, not the stage.

**Rules:** never stock photography, ever — it reads as a lie and costs trust instantly. Don't stage or light it; badly lit and real outperforms polished. One photo per issue in short form, two maximum in long. No logo overlays or borders. Never a client's face or property without asking.

**The caption is the content.** Two sentences, in their own voice, as if texting a mate. The photo earns the attention; the caption converts it.

## One event is three issues

1. **Before** — *"here's what I'm going to find out."* Why they're going and the one question they want answered. This is the issue that gets replies saying *"tell me what you learn."*
2. **After** — *"the one thing that changes what I do on Monday."* Not a summary. One idea, and what they're actually doing differently.
3. **Later** — *"the thing everyone in that room believed that I think is wrong."* The contrarian issue. Highest forward rate of the three by a distance.

**The rule:** nobody cares that they went. They care what it means for them. So never send the group photo with "great few days with great people" — send the photo of the one slide they argued with, and say why.

## Building the story bank

Go pillar by pillar. Keep asking until you have **three stories per pillar** — twelve in total — then move on.

For each one, ask a single question designed to get a real moment, not an opinion. **Vary how you ask**, or they dry up: who was the last client this happened to · what was the job where this went wrong · what did somebody actually say to you · what did you get wrong and have to fix · what number surprised you.

One story at a time. Wait for the answer. Then show back four things and nothing else:

- **THE MOMENT** — the time, the place, the person, in their own words wherever possible
- **THE DETAIL** — the one concrete thing that makes it real: a price, a date, a measurement, a sentence someone said
- **THE NUMBER** — any real figure in what they told you. If there isn't one, ask for one before moving on
- **THE POINT** — what a reader takes away, in one sentence

Then ask for the next.

**Hard rules while collecting:**
- Never invent a client, number, quote or detail they didn't give you.
- Never use a client's name or anything identifying.
- If a story is too thin to carry an issue, say so plainly and ask for a different one rather than padding it out.
- If they give a big impressive claim, push back **once** and ask for the small specific version. *A £4,200 quote on a Tuesday in February beats "transformational results" every single time.*
- Don't make them the hero.
- **If they say they're running out on a pillar, don't force it.** Move on, and note which pillar came out thin — they'll need to watch for material there.

Finish with the bank as a table: story number, pillar, the moment in one line, the detail, the number, the point. Then say which two or three are strongest and which pillar came out thinnest.

## The seven beats

Every good issue is this, in this order.

| # | Beat | What it is |
|---|---|---|
| 1 | **The feeling** | Something the reader already feels, before anything is named. No throat-clearing. *"Most weeks I get to Thursday having been busy every hour, and I couldn't tell you what I actually did."* |
| 2 | **The scene** | One specific moment. A time, a place, a person, a number. *"A Tuesday in February. A quote for £4,200 I was certain I'd lost."* |
| 3 | **The turn** | The thing that surprised **them**. Their own surprise is what earns attention. *"But here's the thing —"* |
| 4 | **The name** | Now, and only now, name the idea. Give it a label the reader could repeat to a colleague. *"That's what I've started calling the making-good gap."* |
| 5 | **The proof** | A number, a study, or a second example — woven into a sentence, never bulleted. If you visualise it, one clean stat or chart. *"Three of my last five jobs. Same pattern."* |
| 6 | **The transfer** | What **they** do about it. One to three things, specific enough to do tomorrow. This is what the reader subscribed for. |
| 7 | **The ask** | One. Never two. Grows out of the story rather than interrupting it. |

## Story rules

**Do:**
- **One story per issue.** Three is a magazine and nobody finishes a magazine.
- **Specific detail beats big claim.** "A Tuesday in February, £4,200" beats "life-changing results" every time.
- **Keep numbers modest and real.** Believable persuades; impressive doesn't.
- **Teach while you tell.** The story is the delivery mechanism, the lesson is the cargo.
- **Be in it, or put someone in it.** A storyless issue is a memo.
- **Steal the shape, never the story.**

**Never:**
- **Rags-to-riches claims.** "Broke to six figures in 90 days" reads as a scam even when it's true — and it repels exactly the people they want.
- **Make them the hero.** Be the one who got it wrong first. That's what earns trust.
- **Invent or composite a client.** One fabricated detail contaminates everything they'll ever write.
- **Explain the moral twice.** Say it once and stop. Trust the reader.
- **Use a client's name or details without asking.**

## Three openings that work

**A trade**
> A Tuesday in February. A quote for £4,200 I was certain I'd lost.
>
> The client rang to say the other lot came in at £2,500. So I said: *"Theirs doesn't include making good. You'll pay for the plaster either way — the only question is whether you pay it now or in March."*
>
> She went with us.

*Scene · turn · the exact sentence · outcome.*

**A coach**
> A client told me last week she'd been *"productive all day and couldn't name one thing she'd done."*
>
> I've heard that sentence maybe forty times this year.
>
> It isn't a time problem. Nothing she did that day had a finish line.

*Their words · frequency as proof · the reframe.*

**A service business**
> We lost a contract last month because of a bin.
>
> Not the cleaning. A bin left in the wrong corridor on a Friday, three weeks running.
>
> Nobody complained. They just didn't renew.

*Specific · surprising · the lesson does itself.*

What all three share: a real moment, a real number or a real sentence someone said, and **no moral tacked on the end.**

## A second frame, for when there's no story

Some weeks they have a position but no scene. Justin Welsh writes one of the most-read solo newsletters in the world in about 45 minutes on this four-step frame:

1. **Name the challenge** you're helping them solve. Say it upfront — it respects their time and tells them whether to keep reading.
2. **Say why solving it matters.** Both sides: what they gain, what it costs to keep ignoring it.
3. **Cover what people normally try, and why it fails.** The step everyone skips, and the one that proves you understand their actual life.
4. **Give your approach, and why it's better.** Clear, numbered, actionable, with a short proof.

Between the seven beats and this, they never face a blank page again.
