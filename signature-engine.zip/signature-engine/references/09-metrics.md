# The numbers — what to measure, and what to ignore

## Two numbers, in this order

**Opens, then clicks. Ignore the rest.**

| Metric | What it tells you |
|---|---|
| **First — open rate** | Did they open it. Diagnoses **exactly two things: the from-name and the subject line.** Nothing else. And it's the least trustworthy number here — see below |
| **Then — unique clicks** | **The highest-leverage number.** One real person, one real click. If clicks per email beat the benchmark, it's working |
| Watch in the background — **delivery rate** | Should be 99%+. Below that means bad addresses or an unauthenticated domain. Fix this before looking at anything else |
| Watch in the background — **unsubscribes** | Under 0.5% per send is healthy. A spike doesn't mean people hate them — **it means the promise got broken.** Go and look at what changed |
| The one that can end it — **spam complaints** | Must stay under 0.3%; aim under 0.1%. Gmail, Yahoo and Microsoft enforce this. A hard technical ceiling, not a guideline |

**Forget click-to-open rate. Forget every other metric in the dashboard.**

## What a real list actually does

The list these numbers come from: **3 million subscribers.**

| | |
|---|---|
| Delivery rate | **99%** |
| Open rate | **40%** |
| Click-through rate | **2.5%** |
| Unsubscribe rate | **0.02%** |

**So what should the user aim for?** Honestly — it depends entirely on their list. A 300-person list of the right people can beat every number above. **The only benchmark that tells them anything true is their own last few issues. Beat those.**

## Open rate is partly fictional

Opens are measured by a tiny invisible image loading. Since Apple Mail Privacy Protection, Apple pre-loads that image whether or not a human ever looked at the email.

- **It can inflate a reported open rate by 15–20 points.**
- **So never compare an open rate to someone else's, or to any benchmark table** — including the one above. Different audiences, different device mixes, different maths.
- **Watch the direction, not the level.** A steady 34% is healthier than a 48% that's been sliding for six issues.
- **Clicks and replies are real.** A human did those. Weight them accordingly.

## Why "good CTR" is a category error

If someone quotes a single "good click rate" number without asking what kind of email it is, they don't know what they're talking about.

**A promo email exists to get a click. A newsletter exists to be read** — it delivers its value inside the email and carries one link. Judge every email against the job it was sent to do. A newsletter with a low click rate and a high reply rate is working exactly as designed.

## At a small list, count conversations

0.33% of 300 subscribers is **one person.** If someone launches next month and judges themselves on click rate, they will conclude it isn't working and stop — and they'll be wrong.

For the first six months, track four things and nothing else:

- **Replies per issue.** One reply per fifty subscribers is genuinely good. Ten replies from the right people is a pipeline.
- **New subscribers per month.** Direction, not size. Twelve a month compounds into something real.
- **Mentions in the wild.** How many people said "I read your thing" before an introduction was finished. Write them down — it'll never be in a dashboard.
- **Issues sent versus issues planned.** The only number that predicts whether this works at all.

So put a real question in every issue — one they genuinely want answered — and reply to every single person who writes back. Personally. **That's the whole trick, and it's the one thing nobody automates.**

## Diagnose by number

| What you see | What's actually broken | What to change |
|---|---|---|
| Low open rate | The from-name or the subject line. **Nothing else** | A person's name in the from-field. More specific subject lines. Stop guessing at content |
| Good opens, low clicks | The copy didn't earn the ask — or there were five links and they picked none | One link. Rewrite the CTA as what happens next. Move it after the value |
| Good clicks, no sales | The landing page, not the email. The email did its job | Fix the page the link goes to. Stop rewriting emails |
| Flat list growth | Not asking in enough places | Signature, LinkedIn featured, one-to-one asks to clients, announce after every send |
| Rising unsubscribes | The promise got broken, the cadence changed, or three sells in a row | Look at what changed in the last three issues. It'll be obvious |
| Spam complaints | People don't remember giving their address | Only add people who opted in. Send *more* often, not less — long gaps cause complaints |
| Nothing's happening at all | 40 subscribers and reading percentages | Count replies |

## The ROI calculation

For when they want it — quarterly, not weekly:

**sends × open rate × click rate × conversion rate × value per customer = revenue**

Then subtract tools, their hours, and any content costs. **(revenue − cost) ÷ cost × 100.**

## Deliverability — the non-negotiables

Since 2024, Gmail, Yahoo and Microsoft enforce sender requirements. Fail them and mail is **rejected, not filtered** — it bounces outright.

1. **Authenticate the domain: SPF, DKIM and DMARC.** A web person does this once, in about ten minutes, in DNS. Most email tools walk you through it. Do it before issue one.
2. **Never send from a personal or business inbox.** Use a proper email platform. Otherwise they risk getting their own domain flagged — and that damages every email they send afterwards, **including their invoices**.
3. **Send from a real name at their own domain.** Not a Gmail address, never a no-reply address.
4. **One-click unsubscribe, always visible.** Making it hard to leave generates spam complaints, which is far worse than losing a subscriber.
5. **Spam complaints under 0.1%.** The threshold is 0.3%; don't go near it.
6. **Never import a list they didn't earn.** No bought lists, no scraped lists, no conference badge dumps. It's the fastest way to destroy a sending reputation that can't easily be rebuilt.
7. **Let the dead go.** If someone hasn't opened anything in twelve months, remove them. A smaller engaged list lands in more inboxes than a big dead one.

## Reference numbers for context

Rough 2026 industry figures, useful only for orientation — not as targets:

| Metric | All industries | Creator / newsletter |
|---|---|---|
| Open rate | ~19–21% | ~35–45% |
| Click rate | ~2.4% | Varies wildly by format |
| Unsubscribe | ~0.5–0.9% | Top performers ≈0.05% |
| Bounce | ~2.5% | — |
