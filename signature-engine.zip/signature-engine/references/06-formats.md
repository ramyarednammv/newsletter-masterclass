# Formats — spec'd to the word, plus design

Pick one shape as the default. That's the ritual and it doesn't change. Let the others in occasionally — a field note when the week has eaten them, a mailbag when someone asks something good, a debrief after an event. **Same day, same voice, same promise. The shape can flex; the appointment cannot.**

## 1 · Long form — 800 to 1,200 words

A four to six minute read. Use it when their **thinking** is the product — coaches, consultants, advisors. Above 1,500 words they'd better be genuinely brilliant. Below 800, commit to short form properly instead.

| Section | Words |
|---|---|
| Subject line + preheader — two different sentences, never the same one twice | — |
| **The hook** — beat 1. Two or three lines. The feeling they already have | 30–50 |
| **The scene** — beat 2. One moment, told properly. Time, place, person, number | 150–250 |
| **The turn** — beat 3. Short. Often its own one-line paragraph | 30–60 |
| **The idea, named** — beat 4. A label they can repeat to a colleague | 60–100 |
| **The proof block** — beat 5. Data in prose. One visual if it genuinely helps. Never a wall of bullets | 150–250 |
| **The transfer** — beat 6. Numbered. One to three things. This is the value | 200–350 |
| **The ask** — beat 7. One button or one question. Never both | 30–50 |
| **Sign-off + P.S.** — same sign-off every week, it's part of the ritual. The P.S. is the second-most-read line in the email | 40–80 |
| **Total** | **800–1,200** |

## 2 · Short form — 180 to 350 words

A 60–90 second read. **Right for most businesses, and everyone should start here.** You can grow into long form and readers will follow; you cannot quietly shrink out of it — they notice, and it reads as giving up.

| Section | Words |
|---|---|
| Subject line + preheader — same rules, and it matters more, there's less inside to save you | — |
| **One-line hook** — beats 1 and 2 collapsed. Straight into the specific | 15–25 |
| **The one thing** — beats 3 and 4. What happened, and what it means. No preamble | 60–100 |
| **Why it matters to you** — beat 5, compressed. One number if there is one | 40–60 |
| **What to do** — beat 6. Three bullets maximum. Often just one | 40–70 |
| **One ask** — beat 7. A question usually beats a button here | 15–25 |
| **Total** | **180–350** |

**No P.S. No sections. No images. No design.** Short form works because it looks like an email from a person who was busy and thought of you anyway. Design it and that spell breaks.

## 3 · The listicle — 300 to 600 words

The most **skimmable** format in email, and the most **forwarded** — someone can send it on with "see number 4". Also the easiest to write on a terrible week, because five small thoughts are much easier than one big one. And it makes the capture note pay off directly: five things they already wrote down become one issue in twenty minutes.

- **Put the number in the subject line.** Odd numbers: 3, 5, 7.
- **One line of framing, then straight into item one.** No introduction.
- **Each item:** a bold label, then two or three sentences. One specific detail in each.
- **No item longer than four lines.** If one runs long, it was its own issue.
- **Put the best item last.** People remember last and forward last.
- **One ask at the end.**

Examples: *"3 things I get asked on every site visit."* · *"5 questions to ask before you sign a maintenance contract."* · *"7 mistakes I made hiring my first engineer."*

## 4 · The field note — 120 to 250 words

One photo from their week, and two or three paragraphs on what it shows. Nothing else. The lowest-effort issue that exists — and often the highest reply rate, because it feels like it was sent to one person. Perfect for trades, access, cleaning, clinics, sites.

## 5 · The event debrief — 250 to 450 words

One thing they learned somewhere, and what they're doing differently on Monday. Use the three-issue structure in `03-stories.md`. Never the group photo without the lesson.

## 6 · The mailbag — 250 to 500 words

A real question a reader or client asked, answered properly and publicly. It proves people write to them, it teaches, and it invites the next question — which is the next issue. The format that compounds fastest once replies start.

---

## Design

**Design does less than you think — until it does everything.**

| What helps | What hurts |
|---|---|
| **One column. Left-aligned. Real text.** Plain beats designed, every time | **A big header image.** It pushes the first line below the fold and slows the load |
| **One photo, doing a job.** Theirs, badly lit, real | **Multi-column layouts.** They collapse into nonsense on a phone |
| **Generous line spacing** and short paragraphs. That *is* the design | **Stock photography.** Instant loss of trust |
| **One button, in their accent colour** — the only colour in the whole email | **Grey text on white.** Use near-black; people read in daylight |
| **Logo small, at the bottom.** Not a banner at the top | **Anything that looks like a brochure.** The moment it looks designed, it reads as an advert |

**The test:** does it look like an email a person sent you, or a campaign a company sent 40,000 people? Design for the first one.
