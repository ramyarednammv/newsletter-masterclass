# Writing and editing an issue

## The copywriter lenses

Use these as how you write and as a silent audit. Don't narrate them.

| Lens | Their one rule |
|---|---|
| **Eugene Schwartz** | Start where the reader's awareness actually is, not where you wish it was. If they don't yet know they have the problem, open there. |
| **Gary Bencivenga** | Proof beats persuasion. Every claim needs something specific behind it, or the claim comes out. |
| **Joseph Sugarman** | The slippery slide. Every sentence exists to make them read the next one, and the first sentence must be almost impossible not to finish. |
| **Ben Settle** | It has to sound like a person with an opinion, not a company being careful. Better disagreed with than ignored. |
| **William Zinsser** | Delete clutter without mercy. Strip every sentence to its cleanest components. |
| **Ann Handley** | The reader is the hero, never the business. |

## The drafting sequence

Work from the story bank row for the issue. If the row is too thin, ask one question before writing anything.

1. **Say in one line where the reader's head is** on this topic before they open it — do they already know they have this problem, or not? Then write to that.
2. **Find the moment they could picture** — a time, a place, a person, a number, a physical detail — and quote the user's own words back. If there are several, take the **smallest and most specific**, not the most impressive.
3. **Name which pillar it belongs to.** If it belongs to none, say so plainly.
4. **Write it** in their shape, inside their word count, using the seven beats.
5. **Write the subject line and preheader** — see `05-subject-lines.md`.

## Hard rules while writing

- **Use their own words and phrases from the raw material wherever possible, including the slightly odd ones.** That's their voice and it's the entire point.
- **Every claim needs something specific behind it, or cut the claim.**
- **Never invent a number, client, testimonial or detail they didn't give.** If you need something, leave a clearly marked gap and list it at the end.
- **Never write their humour.** Where a joke or dry aside belongs: `[HUMAN: short note on what goes here]`.
- **Quote what a client said exactly as they said it, or don't quote it.** Remove anything identifying.
- **Short words. Short sentences. One idea per paragraph. No jargon.**
- **Take a position.** If an issue could have been sent by any competitor, rewrite it.
- **Don't make them the hero. Don't stack adjectives.**
- **Never send, schedule or post anything.**

## How to sound like yourself — the six moves

Give these to the user; they're the whole edit.

1. **Write to one person.** Picture an actual client and use their name in your head. It changes every sentence.
2. **Read it out loud.** Anything you stumble over, cut. Honestly, this is the entire edit.
3. **Sentences under twenty words. Paragraphs of one to three sentences.** White space isn't wasted space.
4. **Use brackets for warmth.** (It's the closest thing writing has to a smile.)
5. **Bold the line you'd say louder.** Italics for the reflective one. Never both, never a whole paragraph.
6. **Keep one weird thing.** Their odd phrase, their obsession, the way they sign off. That's what people remember them by.

Plus **the pub test**: would you say this sentence to them in a pub? If not, rewrite it in the words you'd actually use.

## Delete on sight

unlock · elevate · journey · game-changer · leverage · seamless · robust · synergy · empower · delve

"I hope this email finds you well" · "In today's fast-paced world" · "We're excited to announce" · "As a business owner, you know that…"

And any sentence that could sit in a competitor's newsletter unchanged.

## The AI tells

- **Three adjectives in a row and no specific number.** The fix never changes: delete two adjectives, add one number.
- **Perfectly balanced sentences, all the same length.** Humans are lumpy. Be lumpy.
- **A moral explained twice at the end.**
- **No proper nouns and no prices.** Real writing about a real business is full of both.

## Humour — the one thing you never delegate

**Humour is the fastest way to sound human, which is exactly why you can't write it for them.** You write a joke the way you think a joke is shaped. It lands about one time in twenty, and the other nineteen tell the reader a machine wrote this — the one impression that can't be recovered in an inbox.

So use the marker convention:

> …and the quote came back at £4,200, more than I'd hoped.
>
> **[HUMAN: your dry aside about the client's face here]**
>
> But here's what I hadn't expected —

They fill it in. It takes eleven seconds and it's the difference between sounding like them and sounding like everyone.

**Help them pick a register and stay in it** — consistency of register is part of the ritual:

- **Dry** — "The quote was accepted. Nobody was more surprised than me."
- **Self-deprecating** — "I have now done this wrong in three countries."
- **Deadpan understatement** — "It was a fairly memorable Friday."
- **Sarcastic** — works, but sparingly, and never about a client.

Two other things never to delegate: **the client's actual words** (quote exactly or not at all), and **the numbers** (ask, never guess).

## The first line

It has one job: make them read the second.

**Never:**
> "Hi there! I hope this email finds you well. In today's fast-paced business environment, pricing is one of the most challenging aspects of running a successful contracting business, and many owners struggle to communicate their value effectively…"

Greeting, then context, then throat-clearing. They're gone by word nine.

**Instead:**
> "A Tuesday in February. A quote for £4,200 I was certain I'd lost."
>
> "Then the client rang."

No greeting. No context. Start in the middle of the moment.

## Formatting — design for the six-second skim

Assume they skim before they read.

1. **Clear headings if the format has sections.** A skimmer should get the point from headings alone. If the headings don't survive on their own, rewrite them.
2. **One idea per paragraph, then a line break.** On a phone, a five-line paragraph looks like homework.
3. **Bold sparingly and deliberately** — the four or five phrases that carry the argument, because those *are* what a skimmer reads. Bold everything and you've bolded nothing.
4. **One image, doing a job.** A real photo or one clean stat. Decoration costs loading time and credibility.
5. **Every link goes somewhere worth going.** Mentioning something without linking it creates an itch you refuse to scratch.
6. **Send a test to yourself and read it on your phone**, not a laptop. This catches something roughly one time in three.

## The silent check before showing anything

Check all of these and fix what fails. Show the finished issue, not the checking.

1. **Awareness** — does it start where the reader's head actually is, or assume they already care?
2. **The first line** — does it make them need the second, or open with a greeting or context?
3. **Proof and specifics** — is every claim backed by something real a reader could picture? Any claim without proof comes out.
4. **The promise** — if a subscriber only ever read this issue, would they feel it was kept?
5. **One ask** — exactly one?
6. **The subject line** — specific, under 55 characters, no colon. Does the preheader add a second thought rather than repeat the first?
7. **Personality** — does it sound like a person with an opinion, or a company being careful? Point at any sentence a competitor could have sent unchanged.
8. **Clutter** — which words can come out with nothing lost?
9. **Whose story is it** — is the reader the hero, or the user?
10. **Invented content** — any number, quote, client or claim they didn't supply? **The most important check on the list.**

## Delivering a batch of issues

When writing several at once — the usual case is four, one per pillar:

- Work from the first-four table, one issue per row.
- Deliver each with its pillar, send date, subject line, preheader and full body, ready to paste into their email tool.
- Then **one combined list of every gap and every `[HUMAN]` marker** across all of them, so they know exactly what to fill in.
- Then ask one question: **which one do you want to send first?** When they answer, hand that one back on its own, clean and ready to copy.

Don't show a scorecard. Reviewing is one step too many for someone doing this for the first time — check silently and give them something finished.
