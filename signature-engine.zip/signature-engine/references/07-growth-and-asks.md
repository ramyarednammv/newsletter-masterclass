# The ask, the gift, growth, and the welcome email

## One ask. Every time.

1. **One primary ask per issue.** Other links are fine — **one button.** Two asks means the reader has to choose, choosing is work, so they do neither.
2. **Ask for the next rung, not the top.** The ladder is **read → reply → click → book → buy.** If they've read two issues, don't ask them to buy. Ask them to reply. Every rung skipped halves the number who move.
3. **Place it after the transfer, before the sign-off.** Never at the top — nobody has decided anything yet at the top.
4. **Write what happens next, not what to do.** "See the checklist I use" beats "Click here". "Tell me which one you'd have picked" beats "Reply to this email".
5. **90% useful, 10% selling** — measured across the month, not per email. Then earn the tenth.
6. **The reply is the most undervalued ask in business.** It costs nothing, it teaches the inbox they're a real person (which genuinely helps deliverability), and it starts a conversation a click never will.

## The ask calendar

Map the year's topics against what they're actually selling. Mark the **two or three issues per quarter** that carry a real ask, tied to any dates they gave you. Every other issue asks only for a reply.

This turns 90/10 into a calendar rule rather than a willpower problem — which is the only way it survives a quarter. And it stops the single most damaging pattern: **selling three issues in a row.** One ask per issue is a habit; three in a row is a campaign, and people know the difference instantly.

## The gift — something free in every issue

Every issue should contain one thing they could use even if they never buy. Not a discount every time — *something*. This is what keeps the open rate up over years rather than weeks.

The ladder, cheapest to most valuable:

| Rung | What it is |
|---|---|
| **A specific tip** | One thing they can do tomorrow. Free, instant, always available |
| **A checklist** | The list the user already runs through in their head, written down. Twenty minutes to make |
| **A prompt guide** | The five prompts they actually use in their own business. **The highest-value giveaway available right now** — and most people already have some |
| **A template** | Their quote wording, onboarding email, site checklist. Enormously valuable, almost free to give |
| **A quiz or calculator** | "Which of these three is costing you most?" Interactive, forwarded constantly, and it segments the list for you |
| **A poll** | One click inside the email. **The most underrated tool in email** — it gets engagement from people who'd never reply, and the results tell them what to write next week |
| **Something list-only** | A discount, an early look, a seat. Exclusive to subscribers, never posted publicly. This is what makes people stay and forward |

**The test before every send:** *if they delete this in ten seconds, did they still get something?* If no, trust has been spent without any deposited.

## Growing the list

1. **Ask. Out loud. Repeatedly.** Most small lists are small because the owner never told anyone it existed. A form at the bottom of a website is not asking.
2. **Announce before *and* after you send.** Announcing after reliably brings in more subscribers than announcing before — nobody wants to miss the next one. Post a screenshot of the issue.
3. **Name the incentive, don't describe the newsletter.** "Get the 5 prompts I use to quote a job in 10 minutes" beats "Subscribe to my newsletter" by an enormous margin.
4. **Use their LinkedIn profile properly** — featured link, one line in the About section, and a rotating sign-off on posts.
5. **Their email signature.** Free, forever, and it works on every person they already email.
6. **Ask existing clients directly, one at a time.** Highest conversion of anything on this list. *"I've started writing something short every fortnight — want me to add you?"*
7. **A slide-in on the website, not a full-screen popup.** Mention the incentive, one field. Then tell new subscribers to check spam and add them to contacts — that's the difference between a subscriber and a subscriber who reads them.

## The LinkedIn placement

Three pieces of copy to write for them:

- **The featured link** — a title and a one-line description short enough to read on a phone. *"The Site Notes — every Thursday. One thing that goes wrong on commercial jobs, and how to stop it. Free."*
- **One line in the About section**, ending in a reason to subscribe that's about the reader, not them.
- **Five rotating post sign-offs** that don't all sound the same, and none of which sound like an advert. One of them should work when the post has nothing to do with the newsletter topic.

## The welcome email

**The highest-leverage email they will ever write** — it gets the highest open rate of anything they send, often two to three times a normal issue, because the reader chose them seconds ago. Almost everyone wastes it.

- **Send it instantly.** Not the next day.
- **Under 150 words.** From them, signed by them, replies switched on.
- **Do the four jobs:** confirm what they'll get and when · deliver the gift immediately · ask them one real question · tell them to add the sender to their contacts so it doesn't land in spam.
- **Ask something you actually want answered.** *"What's the one thing you're wrestling with right now?"* Their replies become the next ten issues, in the reader's own words.
- **Don't sell in it. Not once.** There are fifty issues for that and exactly one chance to be the person who gave before asking.

## The signup page

One headline, three short lines on what they get and how often, one button. Nothing else on the page. Assume it takes ten seconds to read.
