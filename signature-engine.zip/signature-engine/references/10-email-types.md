# The 14 kinds of email, and where a newsletter sits

## Why this matters

Most businesses send **two** kinds of email — a promo and an announcement. They get nothing back and conclude email doesn't work for them.

Knowing all fourteen means being able to build any campaign, and understanding why the newsletter is the one that makes the other thirteen land.

## The fourteen

| # | Kind | What it does | Illustrative example |
|---|---|---|---|
| 01 | **Paradigm shift** | Changes how they see the problem, before a solution is ever mentioned | "You don't have a discipline problem. You have an environment problem." |
| 02 | **Concept** | A new idea, a piece of research, a mindset shift. The idea is the hero | "A study on why 6 minutes of breathwork beats an hour of trying to relax" |
| 03 | **Problem–solution** | Names the problem plainly, then shows your fix | "Can't switch off at night? Start here." |
| 04 | **Storytelling** | A narrative carries the point instead of a claim | "I'm turning 50. So I decided to live 100 lives." |
| 05 | **Social proof** | Someone else's result does the selling | "Sandra changed one habit at 58. Here's which one." |
| 06 | **Credibility** | Your own authority — press, awards, years, scale, qualifications | "Meet the teacher: 20 years, three bestsellers, one method" |
| 07 | **Persuasion** | Pure sales, built as an argument rather than an offer | "Three reasons to start before Sunday" |
| 08 | **Direct promo** | The offer itself — a discount, Black Friday, New Year, the summer promo | "Black Friday: one price" |
| 09 | **Last call** | The deadline. Scarcity, used honestly | "Doors close tonight at midnight" |
| 10 | **Announcement** | This new thing exists — a product, a seminar, anything | "Introducing the new programme" |
| 11 | **Invitation** | Come to this. Your RSVP is on hold | "You're invited: 20–22 March. Free." |
| 12 | **WWWW** | What, when, why, **who**. The logistics email nobody bothers to write well | "What, when, why, and who's speaking" |
| 13 | **Video email** | One image, one link, almost no text. A personal Loom counts | "Watch: the 12-minute breakdown" |
| 14 | **Listicle** | Three, five or seven things | "5 morning habits from our longevity teachers" |

**Two of these are formats, not jobs.** Video and listicle are shapes you can put over any of the other twelve — a paradigm shift can be a listicle, social proof can be a video.

## The four pairs that get confused

Getting these wrong means writing the same email twice and wondering why the second one flopped.

| The pair | The actual difference |
|---|---|
| **Paradigm shift vs problem–solution** | **Reframe vs diagnose-and-prescribe.** A paradigm shift changes the frame *before* any solution exists — *"you don't have a pricing problem, you have a scoping problem."* Problem–solution names it plainly and shows the fix. **Shift first, solve second** — do it the other way round and they don't think they have the problem yet |
| **Concept vs storytelling** | **Who's the hero — the idea or the story.** In a concept email the idea is the point and the story is optional. In a storytelling email the story is the vehicle and the idea rides inside it. Concept emails get forwarded; story emails get remembered |
| **Direct promo vs persuasion** | **Offer-led vs argument-led.** A promo leads with the price, the discount, the deadline. A persuasion email can contain no offer at all — it builds the case, then asks. **If the only sales email is a discount, the list has been trained to wait for the next one** |
| **Social proof vs credibility** | **Their evidence vs yours.** Social proof is somebody else's result. Credibility is your own authority — the press mention, the award, the years, the scale. Same job, opposite source. Use both; they answer different worries |

## How a campaign sequences

| Phase | Which emails | What it does |
|---|---|---|
| 1 | Paradigm shift · Concept | Change the frame. Make them see a problem they weren't looking at |
| 2 | Problem–solution · Storytelling | Name it plainly, then make it human so it isn't a lecture |
| 3 | Social proof · Credibility | Remove the risk. Others did this, and I'm safe to buy from |
| 4 | Announcement · Invitation · WWWW | Open the door and take the friction out of walking through it |
| 5 | Persuasion · Direct promo | Make the case, then make the offer |
| 6 | **Last call** | Move the fence-sitters. The money email |

**That sequence is worth more than any single email anyone will ever write.** Most businesses jump to phases 5 and 6 — asking twice, having never shifted anything or proved anything.

Last call is usually the highest-revenue email of any campaign — and the fastest way to burn a list if the deadline isn't real.

## Then there's the newsletter

**The newsletter is not one of the fourteen.**

Every one of those fourteen **spends** trust. The newsletter is the only thing you send that **deposits** it.

> A promo email doesn't fail because of the copy. It fails because it was the first time that person had heard from you in four months.

**So the sequencing rule for the rest of a business's life:** the newsletter runs always. Campaigns sit on top of it, three or four times a year. **Never the other way round.**

## Why a newsletter is a founder's asset

- **It's published under a person's name, not a company's.** Individual credibility builds trust faster than brand credibility, at every size, in every industry.
- **It tells their story weekly, on purpose.** Not once on an About page nobody reads — fifty-two times a year, in the room where decisions get made.
- **It compounds.** Issue forty is worth more than issue one, because by then the reader knows the voice and has been agreeing for nine months.
- **It survives everything.** A rebrand, a pivot, a sale, a new business. The list comes with them.
- **A thousand qualified subscribers beats ten thousand mixed connections.** Every time, and it isn't close.

## The size argument

**300 the right people > 10,000 who once clicked something.**

Three hundred people in a specific role who read something genuinely useful every fortnight, one of whom needs a contractor each quarter, is worth more than ten thousand strangers. Small list, right people, boring on purpose.

An email list is the only audience anyone owns outright. **Nobody can switch it off.** And when it's built on a personal brand, that list follows every product and every service they ever launch.

## Why email at all

**Provenance, because this skill's first rule is never to invent a number:** the figures below are the ones quoted in the masterclass this system comes from. Treat them as approximate and attribute them as such — *"the figures quoted are roughly…"* — rather than presenting them as your own verified research. If a user needs a number they can stand behind publicly, tell them to check the current source themselves.

- Email returns roughly **36:1** on spend — higher than search or paid advertising.
- It's the only channel where **the asset belongs to them.** You rent Google, Meta and LinkedIn. You *own* a list.
- **First email sent in 1971.** It has outlived every platform that was going to replace it.
- **4.73 billion people use email. 8.3 billion inboxes**, because most of us have more than one. **376 billion emails a day. 1.8 billion on Gmail alone.**
- **Everyone anyone will ever want to sell to has an email address.** That is not true of any social platform on earth.

**Why it feels dead:** nobody has been playing with it. Instagram ships a new format every year — stories, reels, lives. Email got none of that for twenty years, so it started to feel like a fax machine. That's changing now: images and GIFs rendering properly, logos in the inbox, own sending domains, one-click unsubscribe.

**Why now:** Steven Bartlett, Jay Shetty, Tony Robbins and Alex Hormozi have all launched newsletters recently — while sitting on some of the largest social followings on earth. Not for reach. Because **owned channel is supremacy**, and a following you rent is not an asset. (This is the framing used in the masterclass; if a user wants to cite specific launch dates, have them verify rather than asserting them.)


---

## Writing a campaign email — the rules that DON'T apply

Sometimes the user doesn't want a newsletter. They want a promo, a last call, an invitation. That's a legitimate, different job — help them do it well rather than steering them back to newsletters.

**Scope these newsletter rules out.** They are about the newsletter as a standing appointment and they do not govern a campaign email:

- *"90% useful, 10% selling"* — that's the balance across a **newsletter's** month. A promo email is 100% selling. That's what it's for.
- *"Never sell three issues in a row"* — that's about the newsletter cadence. A launch sequence deliberately sells across consecutive emails, and it should.
- *"One ask, and ask for the next rung"* — a campaign email asks for the sale directly. The rung ladder is for a newsletter warming a cold reader.
- *"We're building trust, not selling"* — that's the newsletter's job. If someone has a real offer and a real deadline, help them sell it. Don't argue with them.

**What still applies, always:** never invent a number, a claim, a testimonial or a result. Never write their humour. Never fake a deadline. Never send. Those hold everywhere.

### Structure for a direct promo

- **Subject:** the offer and the constraint. *"40% off until Monday"* beats anything clever.
- **First line:** the offer, plainly. No build-up. They already know you're selling — pretending otherwise costs you credibility.
- **What it is, in one short paragraph.** What they get, who it's for.
- **Why now** — the real reason the deadline exists. If there isn't one, say the honest version ("this is the last time at this price") rather than inventing urgency.
- **One or two proof points** — a result, a number, a client sentence. Real ones only.
- **The ask, twice.** Once mid-email, once at the end. Same link, same wording.
- **Price and what happens after they click.** Hiding the price loses more sales than showing it.
- 150–300 words. A promo email is shorter than a newsletter, not longer.

### Structure for a last call

The highest-revenue email of most campaigns, and the easiest to ruin.

- **Subject:** the deadline, flatly. *"Closes tonight."*
- **Open by naming that this is the last email about it.** Readers respect it and it earns the interruption.
- **One short paragraph on what they'd be choosing to miss** — not hype, just the specific thing.
- **The single strongest proof point** from the campaign. One.
- **The link, and the exact deadline time with a timezone.**
- Under 150 words. Nobody reads a long last call.
- **If the deadline is not real, do not send this email.** One fake deadline teaches a list to ignore every future one, and that's unrecoverable.

### If they're planning a whole campaign

Use the six-phase sequence above rather than sending two promos and hoping. Most businesses jump to phases 5 and 6, having never shifted anything or proved anything — and then conclude email doesn't work.