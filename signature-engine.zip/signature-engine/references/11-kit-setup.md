# Getting it into an email tool and sent

Written around Kit (formerly ConvertKit), which is what this system was taught with. The order and the reasoning apply to any tool — Beehiiv, Mailchimp, Substack, Ghost, ActiveCampaign. Only the button names change.

## The setup order — don't improvise this

1. **Sender details first.** From name, from address, and a **physical mailing address**. The address is a legal requirement for bulk email everywhere; a business address is fine. **Do this before anything else or sends will fail later** and it's maddening to debug.
2. **From name is a person**, not just the company. "Scott at Hodgson Plumbing", not "Hodgson Plumbing Ltd". People open people — this matters more than the subject line.
3. **One list. No tags, no segments.** Segmentation is a later problem and it makes beginners freeze. One list until they've sent six issues.
4. **One template, the plainest available.** Text-heavy beats designed: it looks like a person wrote it, and it lands in the inbox better.
5. **Add themselves as a subscriber.** So they receive their own newsletter exactly the way their readers will — not a preview, the real thing.
6. **Paste the issue in.** Kit calls a one-off email a **Broadcast** (sequences are for automated series). **Warn them first: pasting from a chat interface always breaks the spacing.** That's normal, not broken. Fix it and move on.
7. **Send a test to themselves. Read it on a phone, not a laptop** — that's where most readers are.
8. **Then send or schedule.**

**Flag the trial.** Most tools have a 14-day trial. Put the end date in the diary so the bill isn't a surprise.

## The test send — what to actually check

Sending isn't the test. **Receiving is.**

- Did it arrive? Check the inbox **and spam**. If it landed in spam, add yourself to your own contacts — and tell new subscribers to do the same in the welcome email.
- Does the **from name** look right in the inbox list?
- Do the **subject and preheader** read properly next to each other?
- Read it **on a phone**. Any paragraph longer than three lines?
- **Does every link work** and go where it was meant to?

That last one catches something roughly one time in three.

## Uploading subscribers

- **Only people who have agreed to hear from them** — past clients, enquiries, contacts who'd recognise their name. A CSV with email and first name is all any tool needs.
- **Never buy, scrape or import a list they didn't earn.** No conference badge dumps. It's the fastest way to destroy a sending reputation that can't easily be rebuilt, and it will wreck their ability to reach anyone.
- **Start small and real** rather than large and doubtful. Thirty people who know them beats three hundred who don't.
- If they're importing an existing list from another tool, most platforms offer free migration — worth asking support about rather than doing by hand.

## The landing page

One headline, three short lines on what they get and how often, one button. **Nothing else on the page.** Assume it takes ten seconds to read.

Then put the link where people already are: the LinkedIn featured section, the About line, the email signature. A landing page nobody is sent to is just a page.

## Permission for the smallest possible version

The single biggest failure mode is leaving with an unsent draft. People who don't send the first one rarely send any.

So give them explicit permission: **if the list is them and their business partner, send it to the two of them. That counts. They have now sent a newsletter and they are never again someone who hasn't.**

## When something breaks — tell them to ask the tool

Beginners sit on technical problems for a week out of embarrassment. That's the thing to pre-empt.

- **Use the help or support link inside the dashboard.** Quickest route, and it already knows which account they're on.
- **Search the help centre first** — most setup questions are already answered, usually with screenshots.
- **When asking, say exactly what you clicked and exactly what happened.** *"I clicked send test and nothing arrived"* gets a useful answer. *"It's not working"* doesn't.
- **Then ask the group too** — if one person hit it, someone else has.

Support teams exist for exactly this, and it's almost always faster than waiting for the next session.

## Common beginner problems and what they actually are

| Symptom | Usually |
|---|---|
| "The spacing looks wrong after pasting" | Normal. Paste, then fix line breaks manually. Some people paste as plain text first |
| "My test email never arrived" | Sender details incomplete, or it went to spam. Check both before anything else |
| "It's in my spam folder" | Domain not authenticated yet, or a brand new sending reputation. Authenticate SPF/DKIM/DMARC and it settles |
| "It looks fine on my laptop and broken on my phone" | A multi-column template or an image too wide. Switch to one column |
| "I can't find where to send a one-off email" | It's called a Broadcast in Kit. Sequences are for automated series |
| "Do I need a physical address?" | Yes, legally, for bulk email. A business address is fine |

## What "done" looks like

Four newsletters written · the tool set up · **one email sent to themselves that they can actually see in their inbox** · subscribers going in · a landing page live.

That's a working newsletter. Everything after that is doing it again next week.
